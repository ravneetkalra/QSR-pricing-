"""
Menu Price Desk — store-and-product pricing recommendations for a QSR chain.

Run locally:   streamlit run app.py
"""
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from model import (TYPE_ORDER, MONTH_NAMES, Guardrails, contribution_at, fit_pairs,
                   inr, inr_short, load_history, orders_at, pct, recommend,
                   revenue_at, scenario_grid, score_chain)

st.set_page_config(page_title="Menu Price Desk", page_icon=":material/sell:",
                   layout="wide", initial_sidebar_state="auto")

# ------------------------------------------------------------------ palette
NAVY, BLUE, INK, INK2, INK3, RULE = "#0B1F3A", "#2563EB", "#0F172A", "#475569", "#94A3B8", "#E5E8EE"
VERDICT = {"RAISE": "#16A34A", "HOLD": "#64748B", "CUT": "#D97706"}
TINT = {"RAISE": "#DCFCE7", "HOLD": "#F1F5F9", "CUT": "#FEF3C7"}
TYPE_COLOR = {"Premium": "#2563EB", "Mainstream": "#64748B", "Value": "#D97706"}
FONT = "'Plus Jakarta Sans', 'Segoe UI', Roboto, Arial, sans-serif"

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
.stApp, .stApp p, .stApp li, .stApp label, .stApp h1, .stApp h2, .stApp h3, .stApp h4,
.stApp input, .stApp textarea, .stApp button, .stApp .stMarkdown, .stApp td, .stApp th,
.stApp [data-baseweb="select"] div {{ font-family:{FONT}; }}
.block-container {{ padding-top:2.2rem; padding-bottom:3rem; max-width:1320px; }}
h1 {{ font-weight:800 !important; letter-spacing:-.025em; font-size:2rem !important; color:{INK}; }}
h2, h3 {{ font-weight:700 !important; letter-spacing:-.015em; color:{INK}; }}
.stApp p {{ color:{INK2}; }}
[data-testid="stSidebar"] p, [data-testid="stSidebar"] label {{ color:#CBD5E1 !important; }}
[data-testid="stSidebarNav"] a span {{ color:#E2E8F0 !important; font-weight:600; }}
[data-testid="stSidebarNav"] a[aria-current="page"] {{ background:#1E3A66 !important; }}
footer {{ visibility:hidden; }}

.eyebrow {{ font-size:11px; font-weight:700; letter-spacing:.12em; text-transform:uppercase;
  color:{INK3}; margin-bottom:6px; }}
.card {{ background:#fff; border:1px solid {RULE}; border-radius:12px; padding:20px 22px;
  box-shadow:0 1px 2px rgba(15,23,42,.04); height:100%; }}
.kpi .v {{ font-size:28px; font-weight:800; color:{INK}; letter-spacing:-.02em;
  font-variant-numeric:tabular-nums; line-height:1.1; }}
.kpi .s {{ font-size:12.5px; color:{INK2}; margin-top:6px; }}
.badge {{ display:inline-block; padding:4px 10px; border-radius:6px; color:#fff;
  font-size:12px; font-weight:800; letter-spacing:.08em; }}
.verdict-price {{ font-size:40px; font-weight:800; color:{INK}; letter-spacing:-.03em;
  font-variant-numeric:tabular-nums; margin:12px 0 6px; line-height:1; }}
.verdict-price s {{ color:{INK3}; font-weight:600; font-size:28px; margin-right:6px; }}
.verdict-text {{ color:{INK2}; font-size:14.5px; line-height:1.55; margin:8px 0 16px; }}
.stats {{ display:flex; gap:28px; flex-wrap:wrap; border-top:1px solid {RULE}; padding-top:14px; }}
.stats .v {{ font-size:21px; font-weight:800; font-variant-numeric:tabular-nums; color:{INK}; }}
.stats .l {{ font-size:11px; font-weight:700; letter-spacing:.08em; text-transform:uppercase;
  color:{INK3}; margin-top:2px; }}
.why-row {{ display:flex; justify-content:space-between; gap:12px; padding:8px 0;
  border-bottom:1px solid {RULE}; font-size:13.5px; }}
.why-row:last-child {{ border-bottom:0; }}
.why-row .k {{ color:{INK2}; }}
.why-row .v {{ color:{INK}; font-weight:700; font-variant-numeric:tabular-nums; text-align:right; }}
.why-row.lead .k, .why-row.lead .v {{ color:{BLUE}; }}
.binding {{ margin-top:14px; padding:10px 12px; border-radius:8px; background:#EFF6FF;
  color:#1E40AF; font-size:13px; }}

.map {{ width:100%; border-collapse:separate; border-spacing:6px; }}
.map th {{ font-size:11px; font-weight:700; letter-spacing:.08em; text-transform:uppercase;
  color:{INK3}; text-align:center; padding:4px; }}
.map th.store {{ text-align:left; }}
.map td.store {{ font-weight:700; color:{INK}; font-size:13.5px; white-space:nowrap; padding-right:10px; }}
.map td.store small {{ display:block; color:{INK3}; font-weight:500; font-size:12px; }}
.map td.cell {{ border-radius:10px; padding:10px 12px; text-align:center; min-width:120px; }}
.map td.cell .p {{ font-weight:800; font-size:15px; font-variant-numeric:tabular-nums; color:{INK}; }}
.map td.cell .g {{ font-size:12px; margin-top:3px; font-variant-numeric:tabular-nums; font-weight:600; }}
.map td.cell .t {{ font-size:10.5px; font-weight:800; letter-spacing:.08em; margin-bottom:3px; }}
.map tr.group td {{ font-size:11px; font-weight:800; letter-spacing:.12em; text-transform:uppercase;
  padding:12px 0 0; }}
.mapwrap {{ overflow-x:auto; }}

.step {{ background:#fff; border:1px solid {RULE}; border-radius:12px; padding:18px; min-height:200px; }}
.step .n {{ width:28px; height:28px; border-radius:50%; background:{NAVY}; color:#fff;
  display:flex; align-items:center; justify-content:center; font-weight:800; font-size:13px;
  margin-bottom:10px; }}
.step h4 {{ margin:0 0 6px; font-size:15px; font-weight:700; color:{INK}; }}
.step p {{ margin:0; font-size:13.5px; line-height:1.55; }}
.limit {{ background:#fff; border:1px solid {RULE}; border-radius:12px; padding:16px 18px; min-height:215px; }}
.limit.key {{ border-left:5px solid {VERDICT['CUT']}; background:#FFFBEB; }}
.limit h4 {{ margin:0 0 6px; font-size:14.5px; font-weight:700; color:{INK}; }}
.limit p {{ margin:0; font-size:13.5px; line-height:1.55; }}
.sidebrand {{ font-size:20px; font-weight:800; color:#fff; letter-spacing:-.02em; }}
.sidesub {{ font-size:12px; color:#94A3B8; margin-top:2px; }}
</style>
""", unsafe_allow_html=True)


# ------------------------------------------------------------------ data
@st.cache_data
def load():
    raw = load_history(str(Path(__file__).parent / "data" / "sales_history.csv"))
    return fit_pairs(raw)


PAIRS, HIST, SEASON = load()
STORES = PAIRS.drop_duplicates("StoreID")[["StoreID", "Store", "City", "Type", "Competitors"]]
PRODUCTS = PAIRS.drop_duplicates("ProductID")[["ProductID", "Product"]]
STORE_LABEL = {r.StoreID: f"{r.Store} · {r.City}" for r in STORES.itertuples()}
PROD_LABEL = dict(zip(PRODUCTS.ProductID, PRODUCTS.Product))
PROD_SHORT = {"P01": "Chicken Burger", "P02": "Veg Burger", "P03": "Peri Peri Fries", "P04": "Cold Coffee"}

st.session_state.setdefault("store", "S05")
st.session_state.setdefault("product", "P01")
for k, v in (("g_loss", 8), ("g_prem", 5), ("g_move", 10)):
    st.session_state.setdefault(k, v)


def guardrails() -> Guardrails:
    return Guardrails(st.session_state.g_loss / 100, st.session_state.g_prem / 100,
                      st.session_state.g_move / 100)


def pair(sid=None, pid=None):
    sid = sid or st.session_state.store
    pid = pid or st.session_state.product
    return PAIRS[(PAIRS.StoreID == sid) & (PAIRS.ProductID == pid)].iloc[0]


# ------------------------------------------------------------------ helpers
def html(s: str):
    st.markdown(s, unsafe_allow_html=True)


def kpi(label, value, sub="", color=INK, tint="#fff"):
    html(f'<div class="card kpi" style="background:{tint}"><div class="eyebrow">{label}</div>'
         f'<div class="v" style="color:{color}">{value}</div><div class="s">{sub}</div></div>')


def badge(v):
    return f'<span class="badge" style="background:{VERDICT[v]}">{v}</span>'


def base_layout(fig, h=320, ytitle=None, xtitle=None):
    fig.update_layout(
        height=h, margin=dict(l=8, r=12, t=30, b=8), plot_bgcolor="#fff", paper_bgcolor="#fff",
        font=dict(family=FONT, size=12, color=INK2), hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0, title=None),
        hoverlabel=dict(bgcolor="#fff", font=dict(family=FONT, color=INK)),
    )
    fig.update_xaxes(showgrid=False, linecolor=RULE, title=xtitle, ticks="outside", tickcolor=RULE)
    fig.update_yaxes(gridcolor="#EEF1F5", zeroline=False, title=ytitle)
    return fig


def show(fig):
    st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})


def selectors(key):
    c1, c2 = st.columns([1, 1.5])
    with c1:
        st.selectbox("Store", list(STORE_LABEL), format_func=lambda s: STORE_LABEL[s],
                     key=f"{key}_store", index=list(STORE_LABEL).index(st.session_state.store),
                     on_change=lambda: st.session_state.update(store=st.session_state[f"{key}_store"]))
    with c2:
        st.segmented_control("Product", list(PROD_LABEL), format_func=lambda p: PROD_SHORT[p],
                             key=f"{key}_product", default=st.session_state.product,
                             on_change=lambda: st.session_state.update(
                                 product=st.session_state[f"{key}_product"] or st.session_state.product))


# ================================================================== PAGES
def page_overview():
    g = guardrails()
    sc = score_chain(PAIRS, g)
    total = sc.annual.sum()
    base = (sc.today * 12).sum()
    counts = sc.verdict.value_counts()

    html('<div class="eyebrow">Chain overview</div>')
    st.title("Where should each store's prices go?")
    st.markdown("One menu price is charged at all six stores. Below is what each store "
                "*should* charge for each product, and what that is worth over a year.")

    k = st.columns(4)
    with k[0]:
        kpi("Annual opportunity", inr_short(total), f"{pct(total / base)} of today's contribution", BLUE)
    for col, v, txt in ((k[1], "RAISE", "prices go up"), (k[2], "HOLD", "already priced right"),
                        (k[3], "CUT", "prices come down")):
        with col:
            kpi(v, f"{counts.get(v, 0)} <span style='font-size:15px;color:{INK3}'>of 24</span>",
                txt, VERDICT[v], TINT[v])

    st.write("")
    st.subheader("Price map")
    st.caption("Each cell is one store and product. Colour shows the recommendation; the "
               "number below is the annual contribution gain.")

    rows = ['<div class="mapwrap"><table class="map"><thead><tr><th class="store">Store</th>']
    rows += [f"<th>{PROD_LABEL[p]}</th>" for p in PROD_LABEL]
    rows.append("</tr></thead><tbody>")
    for t in TYPE_ORDER:
        rows.append(f'<tr class="group"><td colspan="5" style="color:{TYPE_COLOR[t]}">{t} stores</td></tr>')
        for s in STORES[STORES.Type == t].itertuples():
            rows.append(f'<tr><td class="store">{s.Store}<small>{s.City} · '
                        f'{s.Competitors} competitor{"s" if s.Competitors > 1 else ""} nearby</small></td>')
            for pid in PROD_LABEL:
                r = sc[(sc.StoreID == s.StoreID) & (sc.ProductID == pid)].iloc[0]
                v = r.verdict
                price = inr(r.Price) if v == "HOLD" else f"{inr(r.Price)} → {inr(r.rec)}"
                gain = "no change" if v == "HOLD" else f"{inr(r.annual)}/yr"
                rows.append(f'<td class="cell" style="background:{TINT[v]}">'
                            f'<div class="t" style="color:{VERDICT[v]}">{v}</div>'
                            f'<div class="p">{price}</div>'
                            f'<div class="g" style="color:{VERDICT[v]}">{gain}</div></td>')
            rows.append("</tr>")
    rows.append("</tbody></table></div>")
    html("".join(rows))
    st.info("**The pattern:** Premium stores can raise prices, Mainstream stores are already "
            "priced right, and Value stores earn more by cutting. One chain-wide price gets "
            "all three wrong at once.", icon=":material/insights:")

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Opportunity by store")
        by = (sc.groupby(["Store", "Type"], as_index=False)["annual"].sum()
                .sort_values("annual"))
        fig = go.Figure(go.Bar(
            x=by.annual, y=by.Store, orientation="h",
            marker=dict(color=[TYPE_COLOR[t] for t in by.Type], cornerradius=4),
            text=[inr_short(v) if v else "₹0" for v in by.annual], textposition="outside",
            customdata=by.Type,
            hovertemplate="%{y} (%{customdata})<br>%{text} a year<extra></extra>"))
        base_layout(fig, 330)
        fig.update_layout(hovermode="closest", showlegend=False)
        fig.update_xaxes(showticklabels=False, showgrid=False,
                         range=[0, by.annual.max() * 1.25])
        fig.update_yaxes(gridcolor="rgba(0,0,0,0)")
        show(fig)
    with c2:
        st.subheader("Why: price sensitivity by store type")
        fig = go.Figure()
        for i, t in enumerate(TYPE_ORDER):
            d = PAIRS[PAIRS.Type == t]
            jitter = np.linspace(-0.18, 0.18, len(d))
            fig.add_trace(go.Scatter(
                x=d.Elasticity, y=np.full(len(d), i) + jitter, mode="markers", name=t,
                marker=dict(size=12, color=TYPE_COLOR[t], line=dict(color="#fff", width=2)),
                customdata=np.stack([d.Store, d.Product], axis=1),
                hovertemplate="%{customdata[0]}<br>%{customdata[1]}<br>Elasticity %{x:.2f}<extra></extra>"))
        fig.add_vline(x=-1, line=dict(color=INK3, dash="dash", width=1))
        fig.add_annotation(x=-1, y=2.55, text="−1: where a price rise starts losing revenue",
                           showarrow=False, font=dict(size=11, color=INK3), xanchor="left", xshift=6)
        base_layout(fig, 330, xtitle="Elasticity (more negative = more price-sensitive)")
        fig.update_layout(hovermode="closest", showlegend=False)
        fig.update_yaxes(tickvals=[0, 1, 2], ticktext=TYPE_ORDER, range=[-0.6, 2.75], gridcolor="#F1F3F7")
        show(fig)

    st.subheader("Chain scorecard")
    st.caption("All 24 store-product pairs, ranked by annual gain. Low-confidence rows should "
               "be tested in one store before any rollout.")
    tbl = sc.sort_values("annual", ascending=False)[
        ["Store", "Product", "verdict", "annual", "Price", "rec",
         "d_price", "d_orders", "Elasticity", "Confidence", "Type"]].rename(columns={
            "rec": "Recommended", "d_price": "Price change", "d_orders": "Order change",
            "verdict": "Action", "annual": "Annual gain"})
    st.dataframe(
        tbl.style.format({"Elasticity": "{:.2f}", "Price": inr, "Recommended": inr,
                          "Price change": pct, "Order change": pct, "Annual gain": inr})
           .map(lambda v: f"color:{VERDICT.get(v, INK)};font-weight:700", subset=["Action"]),
        hide_index=True, width="stretch", height=420)

    st.write("")
    c1, c2 = st.columns([2, 1])
    with c1:
        pick = st.selectbox("Open a store and product in detail",
                            PAIRS.index, format_func=lambda i: PAIRS.loc[i, "Label"],
                            index=int(PAIRS[(PAIRS.StoreID == st.session_state.store) &
                                            (PAIRS.ProductID == st.session_state.product)].index[0]))
    with c2:
        st.write("")
        if st.button("Open in Price a Product →", type="primary", width="stretch"):
            st.session_state.store = PAIRS.loc[pick, "StoreID"]
            st.session_state.product = PAIRS.loc[pick, "ProductID"]
            st.switch_page(PAGES["price"])


def page_price():
    g = guardrails()
    html('<div class="eyebrow">Price a product</div>')
    st.title("What should this item cost here?")
    selectors("pp")
    p = pair()
    r = recommend(p, g)
    v = r["verdict"]

    c1, c2 = st.columns([1.15, 1])
    with c1:
        if v == "HOLD":
            price_html = inr(r["rec"])
            sentence = (f"{p.Product} at {p.Store} is already priced where the guardrails allow. "
                        f"Moving it would either lose contribution or break a limit.")
        else:
            price_html = f"<s>{inr(p.Price)}</s>{inr(r['rec'])}"
            direction = "rise" if r["d_orders"] > 0 else "fall"
            sentence = (f"Orders {direction} about {abs(r['d_orders']) * 100:.1f}%, and contribution "
                        f"still grows {pct(r['monthly'] / r['today'])}. The new price lands "
                        f"{pct(r['rec'] / p.CompetitorPrice - 1)} against the nearest competitor "
                        f"at {inr(p.CompetitorPrice)}.")
        gain_color = VERDICT["RAISE"] if r["annual"] > 0 else INK
        html(f'''<div class="card">
          <div class="eyebrow">Recommendation · {p.Store}, {p.City}</div>
          {badge(v)}
          <div class="verdict-price">{price_html}</div>
          <div class="verdict-text">{sentence}</div>
          <div class="stats">
            <div><div class="v" style="color:{gain_color}">{inr(r["annual"])}</div><div class="l">Gain per year</div></div>
            <div><div class="v">{inr(r["monthly"])}</div><div class="l">Gain per month</div></div>
            <div><div class="v">{pct(r["d_orders"])}</div><div class="l">Orders</div></div>
            <div><div class="v">{pct(r["d_price"])}</div><div class="l">Price</div></div>
          </div>
          <div class="binding"><b>What sets this price:</b> {r["binding"]}.</div>
        </div>''')
    with c2:
        rows = [
            ("Store type", f"{p.Type} · {p.Competitors} competitor{'s' if p.Competitors > 1 else ''} within 1 km"),
            ("Price today", inr(p.Price)),
            ("Variable unit cost", f"₹{p.UnitCost:.2f}"),
            ("Gross margin", f"{p.Margin * 100:.1f}%"),
            ("Orders per month", f"{int(p.BaseOrders):,}"),
            ("Competitor price", inr(p.CompetitorPrice)),
            ("Price sensitivity (elasticity)", f"{p.Elasticity:.2f}"),
            ("Confidence in that estimate", f"{p.Confidence} (R² {p.R2:.2f})"),
            ("Contribution today", f"{inr(r['today'])} / month"),
        ]
        body = "".join(f'<div class="why-row{" lead" if "elasticity" in k else ""}">'
                       f'<span class="k">{k}</span><span class="v">{val}</span></div>' for k, val in rows)
        html(f'<div class="card"><div class="eyebrow">Why this price</div>{body}</div>')

    st.write("")
    lo, hi = int(p.Price * 0.75), int(p.Price * 1.30)
    xs = np.arange(lo, hi + 1)
    contrib = np.array([contribution_at(p, x) for x in xs])
    rev = np.array([revenue_at(p, x) for x in xs])
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Contribution at every price")
        peak_i = int(contrib.argmax())
        fig = go.Figure(go.Scatter(x=xs, y=contrib, mode="lines", name="Monthly contribution",
                                   line=dict(color=BLUE, width=3), fill="tozeroy",
                                   fillcolor="rgba(37,99,235,.07)",
                                   hovertemplate="₹%{x}: ₹%{y:,.0f} a month<extra></extra>"))
        ymin, ymax = contrib.min(), contrib.max()
        pad = (ymax - ymin) * 0.25 or ymax * 0.05
        fig.update_yaxes(range=[ymin - pad, ymax + pad])
        fig.add_vline(x=p.Price, line=dict(color=INK3, dash="dash", width=1.5))
        fig.add_vline(x=r["rec"], line=dict(color=VERDICT[v], width=2.5))
        fig.add_annotation(x=p.Price, y=1.0, yref="paper", text="Today", showarrow=False,
                           yanchor="bottom", font=dict(color=INK2, size=11))
        fig.add_annotation(x=r["rec"], y=1.08, yref="paper", text="Recommended", showarrow=False,
                           yanchor="bottom", font=dict(color=VERDICT[v], size=11, weight=700))
        if 0 < peak_i < len(xs) - 1:
            fig.add_trace(go.Scatter(x=[xs[peak_i]], y=[contrib[peak_i]], mode="markers",
                                     name="Profit peak", marker=dict(size=11, color=BLUE,
                                     line=dict(color="#fff", width=2)),
                                     hovertemplate="Peak at ₹%{x}<extra></extra>"))
            note = (f"Contribution peaks at ₹{xs[peak_i]}. The guardrails hold the recommendation "
                    f"at {inr(r['rec'])}.") if xs[peak_i] != r["rec"] else \
                   f"Contribution peaks right at the recommended {inr(r['rec'])}."
        else:
            note = ("Contribution keeps climbing across this range, so a guardrail, not the maths, "
                    f"stops the price at {inr(r['rec'])}.")
        base_layout(fig, 340, ytitle="₹ per month", xtitle="Menu price (₹)")
        fig.update_layout(showlegend=False, hovermode="closest")
        show(fig)
        st.caption(note)
    with c2:
        st.subheader("Revenue vs contribution")
        i0 = int(np.where(xs == int(p.Price))[0][0])
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=xs, y=contrib / contrib[i0] * 100, name="Contribution",
                                 line=dict(color=BLUE, width=3)))
        fig.add_trace(go.Scatter(x=xs, y=rev / rev[i0] * 100, name="Revenue",
                                 line=dict(color=VERDICT["CUT"], width=3, dash="dot")))
        fig.add_vline(x=p.Price, line=dict(color=INK3, dash="dash", width=1.5))
        fig.add_hline(y=100, line=dict(color=RULE, width=1))
        base_layout(fig, 340, ytitle="Index (today = 100)", xtitle="Menu price (₹)")
        fig.update_traces(hovertemplate="%{y:.1f}")
        show(fig)
        st.caption("Both lines start at 100 at today's price. They peak at different prices, "
                   "which is why the tool decides on contribution, not revenue.")

    st.write("")
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("What a 10% discount would do")
        dp = (np.floor(p.Price * 0.9 / 5)) * 5
        do = orders_at(p, dp)
        d_rev = dp * do / (p.Price * p.BaseOrders) - 1
        d_con = (dp - p.UnitCost) * do / r["today"] - 1
        a, b, c = st.columns(3)
        a.metric("Orders", pct(do / p.BaseOrders - 1))
        b.metric("Revenue", pct(d_rev))
        c.metric("Contribution", pct(d_con), delta=inr(((dp - p.UnitCost) * do - r["today"]) * 12) + "/yr",
                 delta_color="normal")
        if d_con < 0:
            st.warning(f"Discounting to {inr(dp)} lifts orders but loses contribution. "
                       "More volume is not more profit here.", icon=":material/trending_down:")
        else:
            st.success(f"Here a cut to {inr(dp)} genuinely pays: customers are price-sensitive "
                       "enough that the extra orders outweigh the lower margin.",
                       icon=":material/trending_up:")
    with c2:
        st.subheader("Stress-test the estimate")
        shift = st.slider("What if customers are more or less price-sensitive than we think?",
                          -0.50, 0.50, 0.0, 0.05, key="stress",
                          help="Shifts the elasticity used. Negative = more price-sensitive.")
        e2 = round(p.Elasticity + shift, 2)
        r2 = recommend(p, g, elasticity=min(e2, -0.05))
        a, b = st.columns(2)
        a.metric("Elasticity tested", f"{e2:.2f}", delta=f"{shift:+.2f} vs estimate" if shift else None,
                 delta_color="off")
        b.metric("Recommendation", f"{r2['verdict']} · {inr(r2['rec'])}",
                 delta=f"{inr(r2['annual'])}/yr", delta_color="normal" if r2["annual"] >= 0 else "inverse")
        same = r2["verdict"] == v
        st.caption(("The direction of the call holds under this shift." if same else
                    "The call changes direction under this shift, so treat it as a hypothesis to "
                    "A/B test before rolling out."))

    st.write("")
    with st.expander("Every price we tested (−20% to +20%)", icon=":material/table_rows:"):
        grid = scenario_grid(p, g)
        st.dataframe(
            grid[["Price", "Change", "Orders", "OrdersChange", "Revenue", "Contribution", "VsToday", "Guardrail"]]
            .rename(columns={"OrdersChange": "Order change", "VsToday": "Contribution vs today"})
            .style.format({"Price": inr, "Change": pct, "Orders": "{:,.0f}", "Order change": pct,
                           "Revenue": inr, "Contribution": inr, "Contribution vs today": pct})
            .apply(lambda row: ["background-color:#DBEAFE;font-weight:700"] * len(row)
                   if row["Price"] == r["rec"] else
                   ["color:#94A3B8"] * len(row) if row["Guardrail"] == "Blocked" else [""] * len(row),
                   axis=1),
            hide_index=True, width="stretch")
        st.caption("Highlighted = recommended. Grey = breaks a guardrail.")


def page_model():
    html('<div class="eyebrow">Demand model</div>')
    st.title("How price-sensitive is each item?")
    st.markdown("Elasticity is estimated from 24 months of each store's own history. "
                "It is the one number the whole recommendation rests on.")
    selectors("dm")
    p = pair()
    h = HIST[(HIST.StoreID == p.StoreID) & (HIST.ProductID == p.ProductID)].sort_values("MonthIdx")

    c1, c2 = st.columns([1.5, 1])
    with c1:
        st.subheader("Every month, and the fitted demand curve")
        promo = h.DiscountPct > 0
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=h.EffectivePrice[~promo], y=h.OrdersAdj[~promo], mode="markers",
                                 name="Full-price month", marker=dict(size=10, color=BLUE,
                                 line=dict(color="#fff", width=1.5))))
        fig.add_trace(go.Scatter(x=h.EffectivePrice[promo], y=h.OrdersAdj[promo], mode="markers",
                                 name="Discount month", marker=dict(size=10, color=VERDICT["CUT"],
                                 symbol="diamond", line=dict(color="#fff", width=1.5))))
        xs = np.linspace(h.EffectivePrice.min() * 0.97, h.EffectivePrice.max() * 1.03, 60)
        fig.add_trace(go.Scatter(x=xs, y=np.exp(p.Intercept) * xs ** p.OwnElasticity, mode="lines",
                                 name=f"Fit: elasticity {p.OwnElasticity:.2f}",
                                 line=dict(color=INK, width=2)))
        base_layout(fig, 360, ytitle="Orders (de-seasonalised)", xtitle="Price charged (₹)")
        fig.update_layout(hovermode="closest")
        fig.update_traces(hovertemplate="₹%{x:.0f} → %{y:,.0f} orders<extra></extra>", selector=dict(mode="markers"))
        show(fig)
        st.caption("Each dot is one month. Discount months sit to the left and, where customers "
                   "are price-sensitive, higher up. The slope of the line is the elasticity.")
    with c2:
        st.subheader("From fit to estimate")
        rows = [("Own estimate (24-month fit)", f"{p.OwnElasticity:.2f}"),
                ("Fit quality (R²)", f"{p.R2:.3f}"),
                ("Confidence", p.Confidence),
                (f"{p.Type} store average", f"{p.TypeAvgElasticity:.2f}"),
                ("Weight on own estimate", f"{p.Weight:.2f}"),
                ("Elasticity used", f"{p.Elasticity:.2f}")]
        body = "".join(f'<div class="why-row{" lead" if k == "Elasticity used" else ""}">'
                       f'<span class="k">{k}</span><span class="v">{v}</span></div>' for k, v in rows)
        html(f'<div class="card">{body}</div>')
        st.write("")
        st.markdown("A 24-month fit can be noisy. Where it is weak, the estimate is pulled toward "
                    "the average for that store type:")
        st.latex(r"e_{used} = w \cdot e_{own} + (1-w)\cdot e_{type}")
        st.latex(r"w = \min(R^2,\ 0.9)")
        st.caption(f"Read it as: a 1% price rise moves orders by {p.Elasticity:.1f}%.")

    c1, c2 = st.columns(2)
    labels = [d.strftime("%b %y") for d in h.MonthDate]
    with c1:
        st.subheader("Price charged")
        fig = go.Figure(go.Scatter(x=labels, y=h.EffectivePrice, mode="lines+markers",
                                   line=dict(color=VERDICT["CUT"], width=2.5), marker=dict(size=6),
                                   hovertemplate="%{x}: ₹%{y:.0f}<extra></extra>"))
        base_layout(fig, 250, ytitle="₹")
        fig.update_xaxes(tickangle=0, tickvals=labels[::4])
        show(fig)
    with c2:
        st.subheader("Orders")
        fig = go.Figure(go.Scatter(x=labels, y=h.Orders, mode="lines+markers",
                                   line=dict(color=BLUE, width=2.5), marker=dict(size=6),
                                   hovertemplate="%{x}: %{y:,} orders<extra></extra>"))
        base_layout(fig, 250, ytitle="Orders")
        fig.update_xaxes(tickangle=0, tickvals=labels[::4])
        show(fig)

    c1, c2 = st.columns([1.6, 1])
    with c1:
        st.subheader("All 24 estimates")
        t = PAIRS[["Store", "Type", "Product", "OwnElasticity", "R2", "Confidence",
                   "TypeAvgElasticity", "Weight", "Elasticity"]].rename(columns={
            "OwnElasticity": "Own fit", "R2": "R²", "TypeAvgElasticity": "Type avg",
            "Elasticity": "Used"})
        st.dataframe(t.style.format({"Own fit": "{:.2f}", "R²": "{:.3f}", "Type avg": "{:.2f}",
                                     "Weight": "{:.2f}", "Used": "{:.2f}"}),
                     hide_index=True, width="stretch", height=380)
    with c2:
        st.subheader("Seasonality index")
        fig = go.Figure(go.Bar(x=MONTH_NAMES, y=[SEASON[m] for m in range(1, 13)],
                               marker=dict(color=[VERDICT["CUT"] if SEASON[m] > 1.05 else "#CBD5E1"
                                                  for m in range(1, 13)], cornerradius=3),
                               hovertemplate="%{x}: %{y:.3f}<extra></extra>"))
        fig.add_hline(y=1, line=dict(color=INK3, dash="dash", width=1))
        base_layout(fig, 300)
        fig.update_yaxes(range=[0.85, 1.15])
        show(fig)
        st.caption("Orders are divided by this index before fitting, so the October–December "
                   "festive peak isn't mistaken for a price effect.")


def page_data():
    html('<div class="eyebrow">Data</div>')
    st.title("The history behind the model")
    st.markdown("576 rows of synthetic monthly data: 6 stores × 4 products × 24 months "
                "(Oct 2024 – Sep 2026). No real chain data was used.")
    c1, c2 = st.columns(2)
    stores = c1.multiselect("Stores", list(STORE_LABEL), format_func=lambda s: STORE_LABEL[s])
    prods = c2.multiselect("Products", list(PROD_LABEL), format_func=lambda p: PROD_LABEL[p])
    d = HIST.copy()
    if stores:
        d = d[d.StoreID.isin(stores)]
    if prods:
        d = d[d.ProductID.isin(prods)]
    view = d[["Month", "StoreName", "City", "Archetype", "ProductName", "ListPrice", "DiscountPct",
              "EffectivePrice", "CompetitorPrice", "Orders", "UnitCost", "Revenue", "Contribution"]]
    view = view.rename(columns={"StoreName": "Store", "Archetype": "Type", "ProductName": "Product",
                                "ListPrice": "List price", "DiscountPct": "Discount",
                                "EffectivePrice": "Price paid", "CompetitorPrice": "Competitor price",
                                "UnitCost": "Unit cost"})
    k = st.columns(4)
    with k[0]: kpi("Rows", f"{len(view):,}")
    with k[1]: kpi("Orders", f"{view.Orders.sum():,}")
    with k[2]: kpi("Revenue", inr_short(view.Revenue.sum()))
    with k[3]: kpi("Contribution", inr_short(view.Contribution.sum()))
    st.write("")
    st.dataframe(view.style.format({"List price": inr, "Discount": "{:.0%}", "Price paid": "₹{:.2f}",
                                    "Competitor price": inr, "Orders": "{:,}", "Unit cost": "₹{:.2f}",
                                    "Revenue": inr, "Contribution": inr}),
                 hide_index=True, width="stretch", height=480)
    c1, c2 = st.columns(2)
    c1.download_button("Download this history (CSV)", view.to_csv(index=False).encode(),
                       "sales_history.csv", "text/csv", width="stretch",
                       icon=":material/download:")
    sc = score_chain(PAIRS, guardrails())
    out = sc[["Store", "City", "Type", "Product", "Elasticity", "Confidence", "Price", "rec",
              "d_price", "d_orders", "verdict", "monthly", "annual"]].rename(columns={
        "rec": "Recommended", "d_price": "PriceChange", "d_orders": "OrderChange",
        "verdict": "Action", "monthly": "MonthlyGain", "annual": "AnnualGain"})
    c2.download_button("Download recommendations (CSV)", out.to_csv(index=False).encode(),
                       "price_recommendations.csv", "text/csv", width="stretch",
                       icon=":material/download:")


def page_method():
    g = guardrails()
    html('<div class="eyebrow">Method & limits</div>')
    st.title("How the recommendation is made")
    steps = [("History", "24 months of prices, discounts, competitor prices and orders for every "
                         "store and product."),
             ("Price sensitivity", "For each pair, how much orders move when price moves 1% "
                                   "(elasticity). Premium stores sit near −0.6; Value stores near −1.7."),
             ("Best price", "The contribution-maximising price for that elasticity and unit cost."),
             ("Guardrails", "Clamp that price to the commercial team's limits and round to the "
                            "nearest ₹5 menu price.")]
    cols = st.columns(4)
    for i, (c, (h, t)) in enumerate(zip(cols, steps), 1):
        with c:
            html(f'<div class="step"><div class="n">{i}</div><h4>{h}</h4><p>{t}</p></div>')

    st.write("")
    c1, c2 = st.columns([1.2, 1])
    with c1:
        st.subheader("The formulas")
        st.latex(r"\text{orders}(p) = \text{orders}_0 \times \left(\tfrac{p}{p_0}\right)^{e}")
        st.latex(r"\text{contribution}(p) = (p - \text{unit cost}) \times \text{orders}(p)")
        st.latex(r"p^{*} = \text{unit cost} \times \frac{e}{e+1} \qquad (e < -1)")
        st.markdown("**Why contribution, not revenue?** A discount can lift orders and revenue "
                    "while cutting the profit on every order. Contribution catches that; revenue "
                    "doesn't. Rent, staff and overheads don't change with a menu price, so they "
                    "stay out of the decision.")
        st.markdown("Where e is above −1, demand is so insensitive that no profit peak exists "
                    "inside the range, and a guardrail sets the price instead.")
    with c2:
        st.subheader("Guardrails in force")
        html(f'''<div class="card">
          <div class="why-row"><span class="k">Most orders we will give up</span><span class="v">{g.max_order_loss:.0%}</span></div>
          <div class="why-row"><span class="k">Most we will sit above a competitor</span><span class="v">{g.max_premium:.0%}</span></div>
          <div class="why-row"><span class="k">Biggest price move in one cycle</span><span class="v">{g.max_move:.0%}</span></div>
          <div class="why-row"><span class="k">Menu price rounding</span><span class="v">₹5</span></div>
        </div>''')
        st.caption("These are the commercial team's risk limits, not the model's output. "
                   "Change them in the sidebar and every page re-solves.")

    st.write("")
    st.subheader("What this model can't tell you")
    lims = [("key", "It only knows prices we've charged",
             "Elasticity comes from prices within about ±15% of today. Outside that band the model "
             "is extrapolating on no evidence. Treat anything beyond it as a hypothesis to A/B test "
             "in one store, not a chain-wide decision."),
            ("", "Items are priced alone",
             "Raising the burger may push customers to fries, or out of the door. Switching between "
             "menu items isn't modelled."),
            ("", "Competitors stand still",
             "Rival prices are held at their last three-month average. If a competitor matches a "
             "cut, the extra volume never arrives."),
            ("", "Small samples",
             "24 months per pair. Low-confidence estimates are shrunk toward the store-type average "
             "and flagged, but they remain weaker evidence.")]
    cols = st.columns(4)
    for c, (cls, h, t) in zip(cols, lims):
        with c:
            html(f'<div class="limit {cls}"><h4>{h}</h4><p>{t}</p></div>')


# ================================================================== NAV
PAGES = {
    "overview": st.Page(page_overview, title="Chain Overview", icon=":material/grid_view:",
                        default=True),
    "price": st.Page(page_price, title="Price a Product", icon=":material/sell:", url_path="price"),
    "model": st.Page(page_model, title="Demand Model", icon=":material/show_chart:", url_path="model"),
    "data": st.Page(page_data, title="Data", icon=":material/table_chart:", url_path="data"),
    "method": st.Page(page_method, title="Method & Limits", icon=":material/menu_book:", url_path="method"),
}

st.logo(str(Path(__file__).parent / "assets" / "logo.svg"), size="large")
nav = st.navigation(list(PAGES.values()))
with st.sidebar:
    html('<div class="sidesub">6 stores · 4 products · 24 months of synthetic data</div>')
    st.divider()
    html('<div class="eyebrow" style="color:#94A3B8">Guardrails</div>')
    st.slider("Most orders we'll give up (%)", 2, 25, key="g_loss")
    st.slider("Most we'll sit above a competitor (%)", 0, 25, key="g_prem")
    st.slider("Biggest price move this cycle (%)", 2, 30, key="g_move")
    st.caption("The commercial team's risk limits. Every page re-solves when you move them.")
    st.button("Reset guardrails", width="stretch",
              on_click=lambda: st.session_state.update(g_loss=8, g_prem=5, g_move=10))
nav.run()

# Menu Price Desk

A pricing prototype for a quick-service restaurant chain. Pick a store and a
product and the app recommends a menu price, shows what it is worth per year,
and explains the evidence behind it.

Built on synthetic data: 6 stores × 4 products × 24 months.

## Pages

| Page | What it shows |
|---|---|
| Chain Overview | Price map for all 24 store-product pairs, total opportunity, chain scorecard |
| Price a Product | The recommendation, contribution curve, revenue vs contribution, discount check, stress test, every tested price |
| Demand Model | How elasticity is estimated: fitted demand curve, price and order history, shrinkage, seasonality |
| Data | The full 576-row history, with CSV downloads |
| Method & Limits | Formulas, guardrails, and what the model can't tell you |

The three guardrails in the sidebar apply to every page.

## Files

```
app.py                     the Streamlit app
model.py                   all the maths (elasticity fit, recommendation, formatting)
data/sales_history.csv     576 rows of synthetic monthly history
assets/logo.svg            sidebar logo
.streamlit/config.toml     colours and theme
requirements.txt           Python packages
```

## Deploy free on Streamlit Community Cloud

1. **Create a GitHub repository.** Go to github.com → New repository → name it
   `menu-price-desk` → Public → Create.
2. **Upload the files.** On the new repo page click *uploading an existing
   file*, drag in everything from this folder, and commit.
   - The `.streamlit` folder is hidden on Mac and Windows, so it is easy to
     miss. If it doesn't upload, click *Add file → Create new file*, type
     `.streamlit/config.toml` as the name, paste the contents of that file,
     and commit.
3. **Deploy.** Go to share.streamlit.io → sign in with GitHub → *Create app* →
   *Deploy a public app from GitHub* → pick the repo, branch `main`, main file
   `app.py` → choose a URL such as `menu-price-desk` → *Deploy*.
4. First build takes 2–3 minutes. You get a link like
   `https://menu-price-desk.streamlit.app`.

**Before an interview or demo:** free apps go to sleep after a few days without
visitors. Open the link 5 minutes beforehand and click *Yes, get this app back
up* if you see it.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

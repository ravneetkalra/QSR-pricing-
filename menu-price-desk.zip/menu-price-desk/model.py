"""
Pricing model for Menu Price Desk.

Everything the commercial team sees is derived here from the raw monthly
history in data/sales_history.csv:

  1. Effective price  = list price x (1 - discount)
  2. Seasonality      = chain-wide monthly order index (Oct-Dec festive peak)
  3. Elasticity       = slope of ln(de-seasonalised orders) on ln(price),
                        fitted per store x product over 24 months
  4. Shrinkage        = weak fits are pulled toward their store-type average,
                        weighted by R^2 (capped at 0.9)
  5. Recommendation   = contribution-maximising price, cost x e/(e+1),
                        clamped between the guardrails, snapped to Rs 5

Rounding mirrors the Excel prototype exactly (Excel rounds half away from
zero, Python's round() does not), so both tools give identical answers.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import pandas as pd

MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
TYPE_ORDER = ["Premium", "Mainstream", "Value"]


def xround(x: float, n: int = 0) -> float:
    """Excel-style ROUND: halves go away from zero."""
    m = 10 ** n
    return math.copysign(math.floor(abs(x) * m + 0.5 + 1e-9) / m, x)


def floor5(x: float) -> float:
    return math.floor(x / 5 + 1e-9) * 5


def ceil5(x: float) -> float:
    return math.ceil(x / 5 - 1e-9) * 5


@dataclass(frozen=True)
class Guardrails:
    max_order_loss: float = 0.08   # most orders we will give up
    max_premium: float = 0.05      # most we will sit above a competitor
    max_move: float = 0.10         # biggest price move in one cycle


# ---------------------------------------------------------------- load + fit
def load_history(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.sort_values(["StoreID", "ProductID", "Month"]).reset_index(drop=True)
    df["MonthIdx"] = df.groupby(["StoreID", "ProductID"]).cumcount() + 1
    df["MonthDate"] = pd.PeriodIndex(df["Month"], freq="M").to_timestamp()
    df["CalMonth"] = df["MonthDate"].dt.month
    df["EffectivePrice"] = df["ListPrice"] * (1 - df["DiscountPct"])
    df["Revenue"] = df["EffectivePrice"] * df["Orders"]
    df["Contribution"] = (df["EffectivePrice"] - df["UnitCost"]) * df["Orders"]
    return df


def seasonality_index(df: pd.DataFrame) -> pd.Series:
    by_month = df.groupby("CalMonth")["Orders"].mean()
    return (by_month / by_month.mean()).round(3)


def fit_pairs(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series]:
    """Returns (pairs, history-with-derived-columns, seasonality index)."""
    season = seasonality_index(df)
    df = df.copy()
    df["SeasonIndex"] = df["CalMonth"].map(season)
    df["OrdersAdj"] = df["Orders"] / df["SeasonIndex"]
    df["lnOrders"] = np.log(df["OrdersAdj"])
    df["lnPrice"] = np.log(df["EffectivePrice"])

    rows = []
    for (sid, pid), g in df.groupby(["StoreID", "ProductID"], sort=True):
        slope, intercept = np.polyfit(g["lnPrice"], g["lnOrders"], 1)
        r2 = np.corrcoef(g["lnPrice"], g["lnOrders"])[0, 1] ** 2
        last = g[g["MonthIdx"] == g["MonthIdx"].max()].iloc[0]
        recent = g[g["MonthIdx"] >= g["MonthIdx"].max() - 2]
        rows.append(dict(
            StoreID=sid, Store=last["StoreName"], City=last["City"],
            Type=last["Archetype"], Competitors=int(last["CompetitorsNearby"]),
            ProductID=pid, Product=last["ProductName"], Category=last["Category"],
            OwnElasticity=xround(slope, 2), Intercept=intercept,
            R2=xround(r2, 3),
            Price=xround(last["ListPrice"], 0),
            UnitCost=xround(last["UnitCost"], 2),
            BaseOrders=xround(recent["Orders"].mean(), 0),
            CompetitorPrice=xround(recent["CompetitorPrice"].mean(), 0),
            MinPriceSeen=float(g["EffectivePrice"].min()),
            MaxPriceSeen=float(g["EffectivePrice"].max()),
        ))
    pairs = pd.DataFrame(rows)

    type_avg = pairs.groupby("Type")["OwnElasticity"].mean().map(lambda v: xround(v, 2))
    pairs["TypeAvgElasticity"] = pairs["Type"].map(type_avg)
    pairs["Weight"] = pairs["R2"].clip(upper=0.9)
    pairs["Elasticity"] = [
        xround(w * own + (1 - w) * avg, 2)
        for w, own, avg in zip(pairs["Weight"], pairs["OwnElasticity"], pairs["TypeAvgElasticity"])
    ]
    pairs["Confidence"] = np.where(pairs["R2"] >= 0.75, "High",
                           np.where(pairs["R2"] >= 0.5, "Medium", "Low"))
    pairs["Margin"] = (pairs["Price"] - pairs["UnitCost"]) / pairs["Price"]
    pairs["Label"] = pairs["Store"] + " · " + pairs["Product"]
    return pairs, df, season


# ---------------------------------------------------------------- the maths
def orders_at(pair, price: float, elasticity: float | None = None) -> float:
    e = pair["Elasticity"] if elasticity is None else elasticity
    return xround(pair["BaseOrders"] * (price / pair["Price"]) ** e, 0)


def contribution_at(pair, price: float, elasticity: float | None = None) -> float:
    return (price - pair["UnitCost"]) * orders_at(pair, price, elasticity)


def revenue_at(pair, price: float, elasticity: float | None = None) -> float:
    return price * orders_at(pair, price, elasticity)


def recommend(pair, g: Guardrails, elasticity: float | None = None) -> dict:
    e = pair["Elasticity"] if elasticity is None else elasticity
    p0, c, b = pair["Price"], pair["UnitCost"], pair["BaseOrders"]

    unconstrained = c * e / (e + 1) if e < -1.02 else None
    target = unconstrained if unconstrained is not None else 1e6

    competitor_cap = max(pair["CompetitorPrice"] * (1 + g.max_premium), p0)
    volume_cap = p0 * 10 if e > -0.05 else p0 * (1 - g.max_order_loss) ** (1 / e)
    move_cap = p0 * (1 + g.max_move)
    upper = min(competitor_cap, volume_cap, move_cap)
    lower = p0 * (1 - g.max_move)

    clamped = float(np.median([lower, target, upper]))
    rec = float(np.median([ceil5(lower), floor5(clamped), floor5(upper)]))

    new_orders = orders_at(pair, rec, e)
    today = (p0 - c) * b
    after = (rec - c) * new_orders

    if upper == competitor_cap and rec >= floor5(upper) and rec > p0:
        binding = "competitor price"
    elif upper == volume_cap and rec >= floor5(upper) and rec > p0:
        binding = "order-loss limit"
    elif rec >= floor5(move_cap) and rec > p0:
        binding = "maximum price move"
    elif rec <= ceil5(lower) and rec < p0:
        binding = "maximum price move"
    elif rec == p0 and unconstrained is None:
        binding = "competitor price"
    else:
        binding = "none — this is the profit-maximising price"

    return dict(
        rec=rec, verdict="RAISE" if rec > p0 else "CUT" if rec < p0 else "HOLD",
        new_orders=new_orders, d_price=rec / p0 - 1, d_orders=new_orders / b - 1,
        today=today, after=after, monthly=after - today, annual=(after - today) * 12,
        unconstrained=unconstrained, upper=upper, lower=lower,
        competitor_cap=competitor_cap, volume_cap=volume_cap, binding=binding,
    )


def scenario_grid(pair, g: Guardrails) -> pd.DataFrame:
    """Every price from -20% to +20% in 2% steps, snapped to Rs 5."""
    p0, b = pair["Price"], pair["BaseOrders"]
    today = (p0 - pair["UnitCost"]) * b
    competitor_cap = max(pair["CompetitorPrice"] * (1 + g.max_premium), p0)
    out = []
    for i in range(21):
        step = -0.20 + 0.02 * i
        price = xround(p0 * (1 + step) / 5, 0) * 5
        actual = price / p0 - 1
        o = orders_at(pair, price)
        d_o = o / b - 1
        contrib = (price - pair["UnitCost"]) * o
        passed = (d_o >= -g.max_order_loss - 1e-9 and price <= competitor_cap + 1e-9
                  and price >= p0 * (1 - g.max_move) - 1e-9 and abs(actual) <= g.max_move + 1e-9)
        out.append(dict(Step=step, Price=price, Change=actual, Orders=o,
                        OrdersChange=d_o, Revenue=price * o, Contribution=contrib,
                        VsToday=contrib / today - 1, Guardrail="Pass" if passed else "Blocked"))
    return pd.DataFrame(out).drop_duplicates(subset="Price", keep="first").reset_index(drop=True)


def score_chain(pairs: pd.DataFrame, g: Guardrails) -> pd.DataFrame:
    res = [recommend(r, g) for _, r in pairs.iterrows()]
    out = pairs.copy()
    for k in ("rec", "verdict", "d_price", "d_orders", "today", "after", "monthly", "annual", "binding"):
        out[k] = [r[k] for r in res]
    return out


# ---------------------------------------------------------------- formatting
def inr(n: float) -> str:
    """Indian digit grouping: 7,73,850."""
    neg = n < 0
    s = str(int(xround(abs(n), 0)))
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts) + "," + tail
    return ("−₹" if neg else "₹") + s


def inr_short(n: float) -> str:
    a = abs(n)
    sign = "−" if n < 0 else ""
    if a >= 1e7:
        return f"{sign}₹{a / 1e7:.2f} Cr"
    if a >= 1e5:
        return f"{sign}₹{a / 1e5:.2f} L"
    return inr(n)


def pct(x: float, d: int = 1) -> str:
    if abs(x) < 0.5 * 10 ** (-d - 2):
        return f"{0:.{d}f}%"
    return f"{'+' if x > 0 else '−'}{abs(x) * 100:.{d}f}%"
